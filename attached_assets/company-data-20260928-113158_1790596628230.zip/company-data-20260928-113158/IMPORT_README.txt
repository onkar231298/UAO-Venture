COMPANY DATA EXPORT — DEVELOPMENT DATABASE

This ZIP contains PostgreSQL-compatible CSV data with column headers,
columns.csv (source column types), and counts.csv (source row counts).
It is a selective data export, not an entire database backup or a
one-click SQL restore. No unrelated users or unrelated app records are included.

How to import in the destination application:
1. Keep this ZIP private. Do NOT commit it to GitHub or make it public.
2. In the destination project, take a database backup first.
3. Have its Agent inspect columns.csv and the destination schema, compare
   counts.csv to existing destination records, and perform a dry run.
4. Map source IDs to destination IDs. Do not overwrite existing companies.
   Import parent rows before child rows and preserve every company/contact/
   thread/campaign relationship. Remap staff/user references to existing
   destination users where appropriate. company_notes.created_by is required.
5. Import transactionally, verify all counts and sample company pages, and
   report any failed/skipped records. Remove the ZIP from the destination
   workspace after the import.

Some company-associated rows refer to users, templates, or products that
are not in this export. The destination Agent must resolve these references
before import. email_campaigns rows are included only where needed by
company-linked recipient records.

File URLs and attachment references in database fields are included, but
the underlying S3/object-storage file bytes are NOT inside this archive.
If the destination uses different storage, copy those objects separately.
This export is a snapshot: records added after it was created are not included.
