OLD PUBLISHED SITE - WEBSITE MANAGEMENT PRODUCT TRANSFER

Source: old published site production database (read-only). JSON preserves all database columns found in production, including fields absent from the local development schema.
Data: 1654 products (active and inactive), 31 categories, 3999 FAQ rows, and classification/link tables. See manifest.json for every count.
The products table contains image/gallery/document URL fields, pricing, SEO, visibility, featured ordering and availability. JSON files are canonical; this is NOT a standard Bulk Upload ZIP.
Important: 40 FAQ rows refer to product IDs absent from the old source product table. These raw rows are retained for audit; do not attach them to a different product. Review them separately.
Media: 505 unique linked URLs were found; 504 file bytes downloaded into media/, 1 could not be downloaded. See media_references.json for source URL -> bundled file mapping and media_failures.json. Some product fields contain flags/text (not URLs) and must remain unchanged. Do not assume old S3 links will remain available: rehost bundled files in the new app's storage and rewrite the mapped URL fields, including gallery arrays, as appropriate.
Product, category, type, tag, health support and FAQ numeric IDs belong ONLY to the source. Match/remap them to destination IDs; preserve product_id SKU, slug and is_active visibility semantics. User/staff IDs (created_by, updated_by) require safe remapping or null handling.
Back up the destination first, dry-run for collisions, preserve destination-only products unless explicitly approved otherwise, and validate restored products/relations/FAQ/media counts. The old site remains writable: check for source changes immediately before import. Do not delete anything based only on this ZIP.
