COMPANIES AND ALL CONTACTS — DEVELOPMENT DATABASE SNAPSHOT

This is a private selective data export, not an automatic database restore.
Only companies and company_contacts are included; email/sales/activity history,
users, and underlying attachment files are not included. Later source edits
are not included. Keep this ZIP private; do not commit it or publish it.

tables/companies.csv: every source company row, including primary email/phone.
tables/company_contacts.csv: every contact row, including primary AND
non-primary ("additional") contacts. Email, phone, WhatsApp, designation,
country code, role and is_primary are on these contact rows. Do NOT filter
company_contacts.csv down to primary contacts. No separate additional-contact
table is required; counts.csv reports the non-primary count for verification.
columns.csv supplies source column types. CSVs have headers; empty fields
represent SQL NULL (check the target's import semantics).

Destination Agent:
1. Identify the correct destination DEVELOPMENT or PRODUCTION database behind
   the missing Company Management records. Take a backup before writing.
2. Inspect target schema, existing companies and contacts, and compare these
   CSV headers/column types. Show a dry-run count of new, matched, ambiguous,
   and conflicting companies/contacts before import.
3. Do not assume source numeric IDs identify the same companies in another
   database. Match confidently using appropriate stable business identifiers
   (e.g. GST when available), manually review ambiguous matches, and never
   merge companies just because names or email addresses look similar.
4. Import only missing company rows; do not overwrite unrelated target data.
   Maintain a source-company-ID to target-company-ID map. Map nullable user
   references to real destination users or null if allowed; don't create
   fake users. Handle duplicate_of references using the company ID map.
5. Import ALL company_contacts.csv rows exactly once, linking each to its
   mapped company. Match existing contacts conservatively, preserving both
   primary and additional contacts and all email/phone/WhatsApp fields.
   Do not silently discard records that fail to map.
6. Use a transaction where possible. Verify source coverage and target
   company pages, especially companies with multiple contacts. Report all
   imported, matched, skipped, and unresolved records. Retain backup and
   remove the private ZIP from the destination workspace after import.
