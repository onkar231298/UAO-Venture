OLD PUBLISHED SITE — COMPANY AND CONTACT TRANSFER

Source: published bright-organic.com database. This archive contains the full companies and company_contacts tables only.
Counts: 2693 company rows, 2194 linked contact rows.
The company_contacts.company_id values refer to companies.id IN THIS ARCHIVE; they are not destination-app IDs.
JSON files preserve nulls, booleans, full contact email/phone/WhatsApp, and all company fields. Use JSON for restoration.
Do NOT upload this ZIP to the existing Bulk Upload screen: it accepts CSV/XLSX only and does not restore separate contact rows.
A controlled destination migration must create/map companies, then map and create every company_contacts row.
User/account foreign keys in companies (e.g. assigned_to, created_by) require explicit mapping or safe null handling.
This export intentionally excludes activities, notes, tasks, leads, messages, orders, and linked file binaries.
Do NOT delete destination companies until a full backup of the destination exists and a restore has been tested.
Because the published site remains writable, reconcile count/max ID again immediately before import for any later additions.
