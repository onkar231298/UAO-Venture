OLD PUBLISHED SITE → NEW APP DEVELOPMENT DATABASE: COMPANY + CONTACT RESTORE

This is a fresh READ-ONLY snapshot of the old PUBLISHED production database, not this workspace's development database. No destination data has been imported or verified by this package.

CANONICAL DATA: companies.json (2698 rows) AND company_contacts.json (2194 rows). company_contacts is a separate database TABLE, not extra columns on companies. ALL 2194 contact records, including 2175 records with is_primary=false, must be inserted into the destination company_contacts table after companies. Each contact's company_id is an OLD ID and must be mapped to its newly inserted/matched destination company ID. Do NOT skip contacts whose email is blank or matches the company's primary email; the names, phones and other fields still matter.

PROOF / HUMAN INSPECTION: companies_with_contacts.json nests every contact under its source company. contacts_with_company.csv is a single row per contact next to the source company's primary email. companies.csv and company_contacts.csv are for inspection ONLY and guard leading spreadsheet formulas; use JSON for exact restoration.

EMAIL COUNTS IN THIS SOURCE: 2520 nonblank company primary emails; 2122 contact rows with email; 2088 contact rows have an email different from their parent company's primary email, covering 933 companies. 72 contact rows do not have an email but must still be restored. 19 contact rows have is_primary=true; do not infer that all remaining contacts are duplicate primaries.

STOP CONDITION: if the importer cannot restore/verify all 2698 source companies AND 2194 source contacts in the destination DEVELOPMENT database, it must report failure; it must not say the migration succeeded. Do NOT use the existing Bulk Upload screen: it does not recreate company_contacts rows. Build/run a controlled, recoverable import in the NEW app. Verify destination rows directly in the database, not only via an export button or UI; if the export function fails, fix it separately.

The new app's current database and its deletion state were not accessed here. Back up what remains there, preview matches, preserve unrelated destination records, and ask for approval before any destructive action. User IDs/assignment fields must be mapped or safely null-handled, never copied blindly. Old source stays writable: recheck counts/deltas immediately before cutover.
